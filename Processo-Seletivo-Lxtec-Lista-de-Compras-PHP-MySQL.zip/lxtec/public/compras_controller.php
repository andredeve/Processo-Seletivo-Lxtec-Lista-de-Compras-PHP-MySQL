<?php

require_once '../app/compras_controller.php';


?>