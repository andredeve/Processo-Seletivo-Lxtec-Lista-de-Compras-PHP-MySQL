<?php

class Compras{
    private $id_lista_compras;
    private $titulo;
    private $data_cadastro;
    
    // Getter Mágico
    public function __get($atributo){
        return $this->$atributo;
    }
    // Setter Mágico
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
}


?>