<?php

require_once '../app/produtos_controller.php';

?>