<?php
  require_once "../app/compras.model.php";
  require_once "../app/compras_produtos.model.php";
  require_once "../app/produto.model.php";
  require_once "../app/compras.service.php";
  require_once "../app/produto.service.php";
  require_once "../app/compras_produtos.service.php";
  require_once "../app/conexao.php";

  $action = isset($_GET['action']) ? $_GET['action'] : $action;

  // Verifica se os campos foram preenchidos
  if ($action == 'insert' && !($_POST['titulo'] == '') && !($_POST['prod'] == '')){
    try{
        $conexao = new Conexao();
        $compras = new Compras();
        $compras->__set('titulo', $_POST['titulo']);
        $comprasService = new ComprasService($conexao, $compras);
        $comprasService->create();

        $compras_dados = $comprasService->return_id($_POST['titulo']);
        $produto = new Produto();
        $produtoService = new ProdutoService($conexao, $produto);
        $compras_produtos = new ComprasProdutos();
        $ComprasProdutosService = new ComprasProdutosService($conexao, $compras_produtos);
        $quantidade = $_POST['quantidade'];
        $produto = $_POST['prod'];
        for ($i=0;$i<count($_POST['quantidade']);$i++){ 
            $produto_dados = $produtoService->return_id($produto[$i]);
            $compras_produtos->__set('id_lista_compras', $compras_dados['ID_LISTA_COMPRAS']);
            $compras_produtos->__set('id_produto', $produto_dados['ID_PRODUTO']); 
            $compras_produtos->__set('quantidade_produto', $quantidade[$i]);
            $ComprasProdutosService->create();
        }
    }catch(Exception $error){
      header('Location: nova_compras?error='.$error->getMessage());
      exit;
    }
    header('Location: todas_compras');
  }else if ($action == 'insertitem' /*&& !($_POST['prod'] == '')*/){
    try{
      $conexao = new Conexao();
      $compras = new Compras();
      $compras->__set('titulo', $_POST['titulo']);
      $comprasService = new ComprasService($conexao, $compras);
      $compras_dados = $comprasService->return_id($_POST['titulo']);  

      $produto = new Produto();
      $produtoService = new ProdutoService($conexao, $produto);

      $compras_produtos = new ComprasProdutos();
      $ComprasProdutosService = new ComprasProdutosService($conexao, $compras_produtos);

      $quantidade = $_POST['quantidade'];
      $produto_lista = $_POST['prod'];

      for ($i=0;$i<count($_POST['quantidade']);$i++){ 
        $compras_produtos->__set('id_lista_compras', $compras_dados['ID_LISTA_COMPRAS']);
        $compras_produtos->__set('id_produto', $produto_lista[$i]); 
        $compras_produtos->__set('quantidade_produto', $quantidade[$i]);
        $ComprasProdutosService->update();
      }
    }catch(Exception $error){
      header('Location: nova_compras?error='.$error->getMessage());
      exit;
    }
    header('Location: todas_compras');
    
  }else if ($action == 'recover'){
    $compras = new Compras();
    $conexao = new Conexao();
    $comprasService = new ComprasService($conexao, $compras);
    $compras_dados = $comprasService->read();
  }else if ($action == 'month'){
    $compras = new Compras();
    $conexao = new Conexao();
    $comprasService = new ComprasService($conexao, $compras);
    $compras_dados = $_GET['month'] == 'all' ? $comprasService->read() : $comprasService->read_por_mes($_GET['month']);
  }else if ($action == 'updating'){ 
    try{
      $compras = new Compras();
      $conexao = new Conexao();
      $compras->__set('titulo', $_POST['titulo']);
      $compras->__set('id_lista_compras', $_POST['id']);
      $comprasService = new ComprasService($conexao, $compras);
      $comprasService->update();
    }catch(Exception $error){
      header('Location: todas_compras?error='.$error->getMessage());
      exit;
    }
    header('Location: todas_compras');
  }else if($action == 'remove'){
    try{
      $compras = new Compras();
      $conexao = new Conexao();
      $compras->__set('id_lista_compras', $_GET['id']);
      $comprasService = new ComprasService($conexao, $compras);
      $comprasService->delete();
    }catch(Exception $error){
      header('Location: todas_compras?error='.$error->getMessage());
      exit;
    }
    header('Location: todas_compras'); 
  }else if($action == 'remove_item'){
    echo 'aqui';
    $conexao = new Conexao();
    $compras_produtos = new ComprasProdutos();
    $ComprasProdutosService = new ComprasProdutosService($conexao, $compras_produtos);
    $compras_produtos->__set('id_produto', $_GET['id']); 
    $ComprasProdutosService->delete();
    header('Location: todas_compras');  
  }else{
    header('Location: nova_compras?error=422');  
  }

?>