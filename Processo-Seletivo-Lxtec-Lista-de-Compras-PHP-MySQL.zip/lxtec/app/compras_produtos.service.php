<?php

// Operações de CRUD de ComprasProdutos
class ComprasProdutosService{
   
   private $conexao;
   private $compras_produtos;

   
   public function __construct(Conexao $conexao, ComprasProdutos $compras_produtos){
      $this->conexao = $conexao->conectar();
      $this->compras_produtos = $compras_produtos;
   }


   public function create(){
     $query = 'INSERT INTO tb_lista_compras_produtos(ID_LISTA_COMPRAS, ID_PRODUTO, QUANTIDADE_PRODUTO) VALUES (:idcompras,:idproduto,:quantidade);';
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->bindValue(':idcompras', $this->compras_produtos->__get('id_lista_compras'));
     $pdostmt->bindValue(':idproduto', $this->compras_produtos->__get('id_produto'));
     $pdostmt->bindValue(':quantidade', $this->compras_produtos->__get('quantidade_produto'));
     $pdostmt->execute();
   }

   public function return_produtos($id_lista_compras){
     $query = "SELECT * FROM tb_lista_compras_produtos WHERE ID_LISTA_COMPRAS ="."'".$id_lista_compras."'";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->execute();
     return $pdostmt->fetchAll(PDO::FETCH_OBJ);
   }
   
   public function read(){
     $query = "SELECT ID_LISTA_COMPRAS, ID_PRODUTO, QUANTIDADE_PRODUTO FROM tb_lista_compras_produtos";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->execute();
     return $pdostmt->fetchAll(PDO::FETCH_OBJ);
   }

   public function update(){
     $query = 'UPDATE tb_lista_compras_produtos set QUANTIDADE_PRODUTO = :quantidade WHERE ID_LISTA_COMPRAS = :idcompras and  ID_PRODUTO = :idproduto';
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->bindValue(':idcompras', $this->compras_produtos->__get('id_lista_compras'));
     $pdostmt->bindValue(':idproduto', $this->compras_produtos->__get('id_produto'));
     $pdostmt->bindValue(':quantidade', $this->compras_produtos->__get('quantidade_produto'));
     if (!($pdostmt->execute())){
      throw new Exception('422');
     }
   }
   
   public function delete(){
    $query = "DELETE FROM tb_lista_compras_produtos WHERE ID_PRODUTO = :id";
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->bindValue(':id', $this->compras_produtos->__get('id_produto'));
    if (!($pdostmt->execute())){
     throw new Exception('422');
    }
   }
}


?>