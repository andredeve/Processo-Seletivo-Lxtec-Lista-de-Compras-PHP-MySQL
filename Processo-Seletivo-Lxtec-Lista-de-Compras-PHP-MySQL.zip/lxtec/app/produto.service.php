<?php

// Operações de CRUD de produtos
class ProdutoService{
   
   private $conexao;
   private $produto;

   
   public function __construct(Conexao $conexao, Produto $produto){
     $this->conexao = $conexao->conectar();
     $this->produto = $produto;
   }

   public function return_nome($id){
    $query = "SELECT NOME FROM tb_produtos WHERE ID_PRODUTO = "."'".$id."'";
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->execute();
    return $pdostmt->fetch();  
   }

   public function return_id($nome){
    $query = "SELECT ID_PRODUTO FROM tb_produtos WHERE nome = "."'".$nome."'";
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->execute();
    return $pdostmt->fetch();  
   }

   public function create(){
    $query = 'INSERT INTO tb_produtos(nome) VALUES (:nome)';
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->bindValue(':nome', $this->produto->__get('nome'));
    if (!($pdostmt->execute())){
      throw new Exception('422');
    }
   }

   public function read(){
     $query = "SELECT ID_PRODUTO, NOME FROM tb_produtos";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     if (!($pdostmt->execute())){
      throw new Exception('422');
    }
     return $pdostmt->fetchAll(PDO::FETCH_OBJ);
   }
   public function update(){
     $query = "UPDATE tb_produtos set NOME = :nome WHERE  ID_PRODUTO = :id";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->bindValue(':nome', $this->produto->__get('nome'));
     $pdostmt->bindValue(':id', $this->produto->__get('id_produto'));
     if (!($pdostmt->execute())){
      throw new Exception('422');
     }
   }
   public function delete(){
     $query = "DELETE FROM tb_produtos WHERE  ID_PRODUTO = :id";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->bindValue(':id', $this->produto->__get('id_produto'));
     if (!($pdostmt->execute())){
      throw new Exception('422');
     }
   }
}


?>