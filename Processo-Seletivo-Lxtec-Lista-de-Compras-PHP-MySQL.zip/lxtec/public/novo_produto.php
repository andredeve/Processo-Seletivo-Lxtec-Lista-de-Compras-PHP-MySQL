<?php 
// Verifica qual é o erro atraves de um URL amigável
$url = $_SERVER['REQUEST_URI'];
$url = explode( '/' , $url);
$url = count($url) >= 2 ? explode('?',$url[3]) : '';
$url = count($url) >= 2 ? explode('=', $url[1]) : '';
$error = $url >= 1 ? $url[1] : '';

if(isset($error) && $error == 422) { ?>
	<div class="bg-danger pt-2 text-white d-flex justify-content-center">
		<h5>Verifique! Produto  já cadastrado ou campo não preenchido corretamente.</h5>
	</div>
<?php } ?>

<div class="container app">
	<div class="row">
		<div class="col-md-3 menu">
			<ul class="list-group">
				<li class="list-group-item"><a href="todas_compras">Listas de Compras</a></li>
				<li class="list-group-item"><a href="nova_compras">Nova Lista de Compras</a></li>
				<li class="list-group-item"><a href="todos_produtos">Lista de Produtos</a></li>
				<li class="list-group-item active"><a href="">Novo Produto</a></li>
			</ul>
		</div>

		<div class="col-md-9">
			<div class="container pagina">
				<div class="row">
					<div class="col">
						<h4>Novo Produto</h4>
						<hr />

						<form method="post" action="produtos_controller.php?action=insert" id="form-cad">
							<div class="form-group">
								<label>Nome do Produto:</label>
								<input type="text" class="form-control"  name="nome" placeholder="Ex. Arroz">
							</div>

							<button class="btn btnpersonalizado">Cadastrar Produto</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>