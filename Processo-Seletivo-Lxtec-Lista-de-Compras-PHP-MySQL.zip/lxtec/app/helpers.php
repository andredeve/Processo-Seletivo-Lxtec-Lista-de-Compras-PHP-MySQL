<?php
  // Função para limitar o tamanho dos detalhes da lista de produtos
  function LimitarDetalhesLista($detalhes){
    $tamanho = strlen($detalhes);
    if ($tamanho > 40){
      return substr($detalhes,0,40).'...';
    }
    else
    {
      return $detalhes;
    }
  }
  
  // Função para Tratar o Titulo da Lista a ser exibido
  function TratarTitulo($titulo){
    $conexao = new Conexao();
    $compras = new Compras();
    $comprasService = new ComprasService($conexao, $compras);
    $compras_dados = $comprasService->return_id($titulo);

    $produto = new Produto();
    $produtoService = new ProdutoService($conexao, $produto);
      
    $compras_produtos = new ComprasProdutos();
    $comprasProdutosService = new ComprasProdutosService($conexao, $compras_produtos);
    $dados_compras_produtos = $comprasProdutosService->return_produtos($compras_dados['ID_LISTA_COMPRAS']);

    $detalhe_lista =  '';

    // Criar o resumo dos produtos da lista de compras
    foreach($dados_compras_produtos as $index => $lista_produtos){
      $produto_dados =  $produtoService->return_nome($lista_produtos->ID_PRODUTO);
      $detalhe_lista = $detalhe_lista.' '.$lista_produtos->QUANTIDADE_PRODUTO.' '.$produto_dados['NOME'].',';
    }

    // Remover a ultima vírgula
    $detalhe_lista = substr($detalhe_lista,0,strlen($detalhe_lista)-1);


    $titulo_tratado = $titulo.' tem'.LimitarDetalhesLista($detalhe_lista).'';

    return $titulo_tratado;
  }


?>