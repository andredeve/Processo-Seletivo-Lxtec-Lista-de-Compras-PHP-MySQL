-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27-Dez-2022 às 23:21
-- Versão do servidor: 10.4.19-MariaDB
-- versão do PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_lista_compras`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_lista_compras`
--

CREATE TABLE `tb_lista_compras` (
  `ID_LISTA_COMPRAS` int(11) NOT NULL,
  `TITULO` varchar(200) NOT NULL,
  `DATA_HORA` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_lista_compras`
--

INSERT INTO `tb_lista_compras` (`ID_LISTA_COMPRAS`, `TITULO`, `DATA_HORA`) VALUES
(3, 'Compras de Natal', '2022-06-26 17:14:57'),
(7, 'Compras de Natal 2022', '2022-12-27 09:42:47');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_lista_compras_produtos`
--

CREATE TABLE `tb_lista_compras_produtos` (
  `ID_LISTA_COMPRAS` int(11) NOT NULL,
  `ID_PRODUTO` int(11) NOT NULL,
  `QUANTIDADE_PRODUTO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_lista_compras_produtos`
--

INSERT INTO `tb_lista_compras_produtos` (`ID_LISTA_COMPRAS`, `ID_PRODUTO`, `QUANTIDADE_PRODUTO`) VALUES
(3, 5, 2),
(7, 5, 2),
(7, 7, 2),
(7, 6, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_produtos`
--

CREATE TABLE `tb_produtos` (
  `ID_PRODUTO` int(11) NOT NULL,
  `NOME` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_produtos`
--

INSERT INTO `tb_produtos` (`ID_PRODUTO`, `NOME`) VALUES
(5, 'Arroz'),
(8, 'Damasco'),
(4, 'Feijão'),
(7, 'Lentilha'),
(6, 'Macarrão');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_lista_compras`
--
ALTER TABLE `tb_lista_compras`
  ADD PRIMARY KEY (`ID_LISTA_COMPRAS`),
  ADD UNIQUE KEY `TITULO` (`TITULO`);

--
-- Índices para tabela `tb_lista_compras_produtos`
--
ALTER TABLE `tb_lista_compras_produtos`
  ADD KEY `ID_LISTA_COMPRAS` (`ID_LISTA_COMPRAS`),
  ADD KEY `ID_PRODUTO` (`ID_PRODUTO`);

--
-- Índices para tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD PRIMARY KEY (`ID_PRODUTO`),
  ADD UNIQUE KEY `NOME` (`NOME`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_lista_compras`
--
ALTER TABLE `tb_lista_compras`
  MODIFY `ID_LISTA_COMPRAS` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  MODIFY `ID_PRODUTO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `tb_lista_compras_produtos`
--
ALTER TABLE `tb_lista_compras_produtos`
  ADD CONSTRAINT `tb_lista_compras_produtos_ibfk_1` FOREIGN KEY (`ID_LISTA_COMPRAS`) REFERENCES `tb_lista_compras` (`ID_LISTA_COMPRAS`) ON DELETE CASCADE,
  ADD CONSTRAINT `tb_lista_compras_produtos_ibfk_2` FOREIGN KEY (`ID_PRODUTO`) REFERENCES `tb_produtos` (`ID_PRODUTO`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
