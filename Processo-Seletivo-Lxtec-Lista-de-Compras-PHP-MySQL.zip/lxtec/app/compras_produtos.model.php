<?php

class ComprasProdutos{
    private $id_lista_compras;
    private $id_produto;
    private $quantidade_produto;
    
    // Getter Mágico
    public function __get($atributo){
        return $this->$atributo;
    }
    // Setter Mágico
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
}


?>