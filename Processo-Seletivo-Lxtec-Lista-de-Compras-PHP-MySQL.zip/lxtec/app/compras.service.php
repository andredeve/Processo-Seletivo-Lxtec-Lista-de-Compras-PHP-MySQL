<?php

// Operações de CRUD de compras
class ComprasService{
   
   private $conexao;
   private $compras;

   public function __construct(Conexao $conexao, Compras $compras){
     $this->conexao = $conexao->conectar();
     $this->compras = $compras;
   }

   public function create(){
     $query = 'INSERT INTO tb_lista_compras(TITULO) VALUES (:titulo)';
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->bindValue(':titulo', $this->compras->__get('titulo'));
     if (!($pdostmt->execute())){
      throw new Exception('422');
     }
   }

   public function return_id($titulo){
     $query = "SELECT ID_LISTA_COMPRAS FROM tb_lista_compras WHERE TITULO = :titulo";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->bindValue(':titulo', $titulo);
     if (!($pdostmt->execute())){
       throw new Exception('422');
     }
     return $pdostmt->fetch();  
   }

   public function read_por_mes($mes){
    $query = "SELECT ID_LISTA_COMPRAS, TITULO FROM tb_lista_compras WHERE MONTH(DATA_HORA) = :mes";
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->bindValue(':mes', $mes);
    if (!($pdostmt->execute())){
      throw new Exception('422');
    }
    return $pdostmt->fetchAll(PDO::FETCH_OBJ);
  }

   public function read(){
     $query = "SELECT ID_LISTA_COMPRAS, TITULO FROM tb_lista_compras";
     // PDO STATEMENT
     $pdostmt = $this->conexao->prepare($query);
     $pdostmt->execute();
     return $pdostmt->fetchAll(PDO::FETCH_OBJ);
   }

   public function update(){
    $query = "UPDATE tb_lista_compras set TITULO = :titulo WHERE  ID_LISTA_COMPRAS = :id";
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->bindValue(':titulo', $this->compras->__get('titulo'));
    $pdostmt->bindValue(':id', $this->compras->__get('id_lista_compras'));
    if (!($pdostmt->execute())){
     throw new Exception('422');
    }
   }
   
   public function delete(){
    $query = "DELETE FROM tb_lista_compras WHERE  ID_LISTA_COMPRAS = :id";
    // PDO STATEMENT
    $pdostmt = $this->conexao->prepare($query);
    $pdostmt->bindValue(':id', $this->compras->__get('id_lista_compras'));
    if (!($pdostmt->execute())){
     throw new Exception('422');
    }
   }
}


?>