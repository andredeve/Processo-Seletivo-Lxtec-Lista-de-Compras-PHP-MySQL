<?php
  $action = 'recover';
  require_once 'compras_controller.php';
  require_once '../app/helpers.php';

  $conexao = new Conexao();
  $compras = new Compras();
  $comprasService = new ComprasService($conexao, $compras);
  $compras_dados = $comprasService->return_id($_GET['titulo']);
  $compras_produtos = new ComprasProdutos();
  $comprasProdutosService = new ComprasProdutosService($conexao, $compras_produtos);
  $dados_compras_produtos = $comprasProdutosService->return_produtos($compras_dados['ID_LISTA_COMPRAS']);

  function NomeProduto($id){
    $conexao = new Conexao();
    $produto = new Produto();
    $produtoService = new ProdutoService($conexao, $produto);
    $nome = $produtoService->return_nome($id);
    return $nome['NOME'];
  }
  function QuantidadeProduto($id, $titulo){
    $conexao = new Conexao();
    $compras = new Compras();
    $comprasService = new ComprasService($conexao, $compras);
    $compras_dados = $comprasService->return_id($titulo);
    $compras_produtos = new ComprasProdutos();
    $comprasProdutosService = new ComprasProdutosService($conexao, $compras_produtos);
    $dados_compras_produtos = $comprasProdutosService->return_produtos($compras_dados['ID_LISTA_COMPRAS']);  
    return $dados_compras_produtos;  
  }
?>

<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>App Lista de Compras</title>

		<link rel="stylesheet" href="css/estilo.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.5.0.js"></script>

    <script>
      // Função para solicitar a atualização do titulo da lista
      function editar_compras(id, compra_titulo) {
         //criar um form de edição
         let form = document.createElement('form')
         form.action = 'compras_controller.php?action=updating'
         form.method = 'post'
         form.className = 'row'
         //criar um input para entrada do texto
         let inputProduto = document.createElement('input')
         inputProduto.type = 'text'
         inputProduto.name = 'titulo'
         inputProduto.className = 'col-9 form-control'
         inputProduto.value = compra_titulo
         //criar um input hidden para guardar o id da Produto
         let inputId = document.createElement('input')
         inputId.type = 'hidden'
         inputId.name = 'id'
         inputId.value = id
         //criar um button para envio do form
         let button = document.createElement('button')
         button.type = 'submit'
         button.className = 'col-3 btn btnpersonalizado'
         button.innerHTML = 'Atualizar'
         //incluir inputProduto no form
         form.appendChild(inputProduto)
         //incluir inputId no form
         form.appendChild(inputId)
         //incluir button no form
         form.appendChild(button)
         //
         let produto = document.getElementById('produto_'+id)
         produto.innerHTML =  ''
         // 
         produto.insertBefore(form, produto[0])
      }

      // Função para solicitar a remoção da lista de compras
      function remover_compras(id){
         location.href = 'compras_controller.php?action=remove&id='+id
      }
      // Função para solicitar a remoção de um produto
      function remover_produto(id){
         location.href = 'compras_controller.php?action=remove_item&id='+id
      }

    </script>
	</head>

	<body>
		<nav class="navbar navbar-light bg-light">
			<div class="container">
				<a class="navbar-brand" href="#">
					<img src="img/logo.png" width="30" height="30" class="d-inline-block align-top" alt="">
					App Lista de Compras
				</a>
			</div>
		</nav>

        <div class="container app">
            <div class="row">
                <div class="col-sm-3 menu">
                    <ul class="list-group">
                        <li class="list-group-item active"><a href="#">Listas de Compras</a></li>
                        <li class="list-group-item"><a href="nova_compras">Nova Lista de Compras</a></li>
                        <li class="list-group-item"><a href="todos_produtos">Lista de Produtos</a></li>
                        <li class="list-group-item"><a href="novo_produto">Novo Produto</a></li>
                    </ul>
                </div>

                <div class="col-sm-9">
                    <div class="container pagina">
                        <div class="row">
                            <div class="col">
                            
                                <div class="row mb-2 d-flex align-items-center tarefa">
                                    <h4 class="col-sm-10" id="produto_<?php echo $compras_dados['ID_LISTA_COMPRAS'] ?>">
                                      <?php echo $_GET['titulo'] ?>
                                    </h4>
                                    <div class="col-sm-2 mt-2 d-flex justify-content-between">
                                    <i class="fas fa-edit fa-lg text-info" onclick="editar_compras(<?php echo $compras_dados['ID_LISTA_COMPRAS']?>, '<?php echo $_GET['titulo']?>')"></i>		
                                    <i class="fas fa-trash-alt fa-lg text-danger" onclick="remover_compras(<?php echo $compras_dados['ID_LISTA_COMPRAS']?>)"></i>						
                                    </div>
                                </div>

                                <hr />
                                <form method="post" action="compras_controller.php?action=insertitem" id="form-cad">
                                    <div class="form-group">

                                        <?php foreach($dados_compras_produtos as $index => $lista_produtos) { ?>
                                            <div class="row mb-2 d-flex align-items-center">
                                                <div class="list-group-item align-items-start">
                                                    <div class="btn-group" style="width: 100%;">
                                                        <div class="form-group" style="margin-right: 5px;">
                                                            <label>Quantidade</label>
                                                            <input class="form-control" type="number" min="1" name="quantidade[]" value="<?php echo $lista_produtos->QUANTIDADE_PRODUTO?>">
                                                        </div>
                                                        <div class="form-group" style="width: 600px;">
                                                            <label>Produto</label>
                                                            <div class="btn-group" style="width: 100%;">
                                                                <select class="form-control" type="text" name="prod[]">
                                                                    <option value="<?php echo $lista_produtos->ID_PRODUTO?>"><?php echo NomeProduto($lista_produtos->ID_PRODUTO)?></option>
                                                                </select>
                                                                <div class="col-sm-1 mt-2 d-flex justify-content-between">
                                                                    <i class="fas fa-trash-alt fa-lg text-danger" onclick="remover_produto(<?php echo $lista_produtos->ID_PRODUTO?>)" ></i>						
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                       
                                        <!-- Input do tipo "hidden" para guardar o Titulo  da Lista de COmpras --> 
                                        <input type="hidden" id="titulo" name="titulo" value="<?php echo $_GET['titulo']?>">
                                        <!---->

                                    </div>
                                    <button class="btn btnpersonalizado">Salvar Alteração</button>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</body>
</html>

