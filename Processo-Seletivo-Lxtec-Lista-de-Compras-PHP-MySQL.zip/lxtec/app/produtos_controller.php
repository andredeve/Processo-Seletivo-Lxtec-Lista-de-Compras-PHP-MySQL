<?php
  require_once "../app/conexao.php";
  require_once "../app/produto.model.php";
  require_once "../app/produto.service.php";
  
  $action = isset($_GET['action']) ? $_GET['action'] : $action;

  // Verifica se os campos foram preenchidos
  if ($action == 'insert' && !($_POST['nome'] == '')){
    try{
      $conexao = new Conexao();
      $produto = new Produto();
      $produto->__set('nome', $_POST['nome']);
      $produtoService = new ProdutoService($conexao, $produto);
      $produtoService->create();
    }catch(Exception $error){
      header('Location: novo_produto?error='.$error->getMessage());
      exit;
    }
    header('Location: todos_produtos');
  }else if ($action == 'recover'){
    $conexao = new Conexao();
    $produto = new Produto();
    $produtoService = new ProdutoService($conexao, $produto);
    $produto_dados =  $produtoService->read();
  }else if($action == 'updating'){
    try{
      $conexao = new Conexao();
      $produto = new Produto();
      $produto->__set('id_produto', $_POST['id']);
      $produto->__set('nome', $_POST['produto']);
      $produtoService = new ProdutoService($conexao, $produto);
      $produtoService->update();
    }catch(Exception $error){
      header('Location: todos_produtos?error='.$error->getMessage());
      exit;
    }
    header('Location: todos_produtos');
  }else if ($action == 'remove'){
    try{
      $conexao = new Conexao();
      $produto = new Produto();
      $produto->__set('id_produto', $_GET['id']);
      $produtoService = new ProdutoService($conexao, $produto);
      $produtoService->delete();
    }catch(Exception $error){
      header('Location: todos_produtos?error='.$error->getMessage());
      exit;
    }
    header('Location: todos_produtos'); 
  }else{
    header('Location: novo_produto?error=422'); 
  }
?>