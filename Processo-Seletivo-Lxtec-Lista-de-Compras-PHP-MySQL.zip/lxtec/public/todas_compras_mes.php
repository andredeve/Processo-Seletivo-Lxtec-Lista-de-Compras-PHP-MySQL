<?php
  $action = 'month';
  require_once 'compras_controller.php';
  require_once '../app/helpers.php';
  
?>
<?php 
// Verifica qual é o erro atraves de um URL amigável
$url = $_SERVER['REQUEST_URI'];
$url = explode( '/' , $url);
$url = count($url) >= 2 ? explode('?',$url[3]) : '';
$url = count($url) >= 2 ? explode('=', $url[1]) : '';
$error = $url >= 1 ? $url[1] : '';

if( isset($error) && $error == 422 ) { ?>
	<div class="bg-danger pt-2 text-white d-flex justify-content-center">
		<h5>Verifique! Lista já cadastrada ou campo não preenchido corretamente.</h5>
	</div>
<?php } ?>

<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>App Lista de Compras</title>

		<link rel="stylesheet" href="css/estilo.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.5.0.js"></script>

    <script>
      // Função para solicitar a atualização da lista de compras
      function editar_compras(id, titulo){
        location.href = 'lista_compras.php?id='+id+'&titulo='+titulo
      }
      // Obtem o mês selecionado para filtrar
      function filtrar(){
        let mes = document.getElementById('filtro_mes')
        location.href = 'todas_compras_mes.php?month='+mes.value
      }
    </script>
	</head>

	<body>
		<nav class="navbar navbar-light bg-light">
			<div class="container">
				<a class="navbar-brand" href="#">
					<img src="img/logo.png" width="30" height="30" class="d-inline-block align-top" alt="">
					App Lista de Compras
				</a>
			</div>
		</nav>

        <div class="container app">
            <div class="row">
                <div class="col-sm-3 menu">
                    <ul class="list-group">
                        <li class="list-group-item active"><a href="#">Listas de Compras</a></li>
                        <li class="list-group-item"><a href="nova_compras">Nova Lista de Compras</a></li>
                        <li class="list-group-item"><a href="todos_produtos">Lista de Produtos</a></li>
                        <li class="list-group-item"><a href="novo_produto">Novo Produto</a></li>
                    </ul>
                </div>

                <div class="col-sm-9">
                    <div class="container pagina">
                        <div class="row">
                            <div class="col">
                                <h4>Listas de Compras</h4>

                                <div class="btn-group" style="width: 100%;">
                                        <select  class="form-control"  id="filtro_mes"  data-placeholder="Selecione o mês">
                                       
                                            <option value="all" <?php echo $_GET['month'] == 'all' ? 'selected' : ''?>>Todos</option>
                                            <option value="1" <?php echo $_GET['month'] == 1 ? 'selected' : ''?>>Janeiro</option>
                                            <option value="2" <?php echo $_GET['month'] == 2 ? 'selected' : ''?>>Fevereiro</option>
                                            <option value="3" <?php echo $_GET['month'] == 3 ? 'selected' : ''?>>Março</option>
                                            <option value="4" <?php echo $_GET['month'] == 4 ? 'selected' : ''?>>Abril</option>
                                            <option value="5" <?php echo $_GET['month'] == 5 ? 'selected' : ''?>>Maio</option>
                                            <option value="6" <?php echo $_GET['month'] == 6 ? 'selected' : ''?>>Junho</option>
                                            <option value="7" <?php echo $_GET['month'] == 7 ? 'selected' : ''?>>Julho</option>
                                            <option value="8" <?php echo $_GET['month'] == 8 ? 'selected' : ''?>>Agosto</option>
                                            <option value="9" <?php echo $_GET['month'] == 9 ? 'selected' : ''?>>Setembro</option>
                                            <option value="10" <?php echo $_GET['month'] == 10 ? 'selected' : ''?>>Outubro</option>
                                            <option value="11" <?php echo $_GET['month'] == 11 ? 'selected' : ''?>>Novembro</option>
                                            <option value="12" <?php echo $_GET['month'] == 12 ? 'selected' : ''?>>Dezembro</option>

                                        </select>
                                        <button type="button" class="btn btnpersonalizado"  id="btn_filtrar" onclick="filtrar()">Filtrar</button>
                                </div>
                                <hr />

                                <?php foreach($compras_dados as $index => $lista_compras) { ?>

                                    <div class="row mb-2 d-flex align-items-center">
                                        <div class="col-sm-10" id="compras_<?php echo $lista_compras->ID_LISTA_COMPRAS?>">
                                            <?php echo TratarTitulo($lista_compras->TITULO) ?>
                                        </div>
                                        <div class="col-sm-2 mt-2 d-flex justify-content-between">
                                        <i class="fas"></i>					 
                                        <i class="fas fa-edit fa-lg text-info" onclick="editar_compras(<?php echo $lista_compras->ID_LISTA_COMPRAS?>, '<?php echo $lista_compras->TITULO?>')"></i>
                                        </div>
                                    </div>

                                <?php } ?>
                                
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
	</body>
</html>

