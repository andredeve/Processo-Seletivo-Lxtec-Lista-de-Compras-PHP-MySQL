<?php
  $action = 'recover';
  require_once 'produtos_controller.php';
?>
<?php 
// Verifica qual é o erro atraves de um URL amigável
$url = $_SERVER['REQUEST_URI'];
$url = explode( '/' , $url);
$url = count($url) >= 2 ? explode('?',$url[3]) : '';
$url = count($url) >= 2 ? explode('=', $url[1]) : '';
$error = $url >= 1 ? $url[1] : '';

if(isset($error) && $error == 422 ) { ?>
	<div class="bg-danger pt-2 text-white d-flex justify-content-center">
		<h5>Verifique! Lista já cadastrada ou campos não preenchidos corretamente.</h5>
	</div>
<?php } ?>

<div class="container app">
	<div class="row">
		<div class="col-md-3 menu">
			<ul class="list-group">
				<li class="list-group-item"><a href="todas_compras">Listas de Compras</a></li>
				<li class="list-group-item active"><a href="">Nova Lista de Compras</a></li>
				<li class="list-group-item"><a href="todos_produtos">Lista de Produtos</a></li>
				<li class="list-group-item"><a href="novo_produto">Novo Produto</a></li>
			</ul>
		</div>

		<div class="col-md-9">
			<div class="container pagina">
				<div class="row">
					<div class="col">
						<h4>Nova Lista de Compras</h4>
						<hr />

						<form method="post" action="compras_controller.php?action=insert" id="form-cad">
							<div class="form-group">
								<label>Título da Lista:</label>
								<input type="text" class="form-control"  name="titulo" placeholder="Ex. Compras de Natal">
								
								
								<label>Produtos: </label>

								<div class="form-group" id="form">
								<!--Lista de Produtos-->	
								</div>			

								<div class="btn-group" style="width: 100%;">
								<select  class="form-control"  id="nome_produto" data-placeholder="Selecione o Produto">
								
									<?php foreach($produto_dados as $index => $produto) { ?>	
										<option value="<?php  echo $produto->NOME ?>"><?php  echo $produto->NOME ?></option>
									<?php } ?>

								</select>
								<button type="button" class="btn btnpersonalizado"  id="add-campo-teste">Adicionar Produto</button>
								</div>

							</div>

							<button class="btn btnpersonalizado">Cadastrar Lista de Compras</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	var $produto =  document.querySelector('#nome_produto');
	// var $quantidade =  document.querySelector('#quantidade_servico');
	var cont = 1;

	$('#add-campo-teste').click(function (){
	cont++;
	//https://api.jquery.com/append/
	$('#form').append('<div class="list-group-item align-items-start" id="campo' + cont + '"><div class="btn-group" style="width: 100%;"><div class="form-group" style="margin-right: 5px;"><label>Quantidade</label><input class="form-control" name="quantidade[]" type="text" placeholder="Quantidade" value="' +1+ '"></div><div class="form-group" style="width: 600px;"><label>Produto</label><div class="btn-group" style="width: 100%;"><select class="form-control" type="text" name="prod[]"><option value="' + $produto.value + '"">' + $produto.value + '</option></select><button type="button" id="' + cont + '" class="btn btn-danger"> <i class="fas fa-trash-alt fa-lg text-white"></i> </button></div>');
	});

	$('#form').on('click', '.btn-danger', function () {
		var button_id = $(this).attr("id");
		$('#campo' + button_id + '').remove();
		
	});

			
</script>