<?php
  $action = 'recover';
  require_once 'produtos_controller.php';
  
?>
<?php 
// Verifica qual é o erro atraves de um URL amigável
$url = $_SERVER['REQUEST_URI'];
$url = explode( '/' , $url);
$url = count($url) >= 2 ? explode('?',$url[3]) : '';
$url = count($url) >= 2 ? explode('=', $url[1]) : '';
$error = $url >= 1 ? $url[1] : '';

if( isset($error) && $error == 422 ) { ?>
	<div class="bg-danger pt-2 text-white d-flex justify-content-center">
		<h5>Verifique! Produto já cadastrado ou campo não preenchido corretamente.</h5>
	</div>
<?php } ?>

<div class="container app">
	<div class="row">
		<div class="col-sm-3 menu">
			<ul class="list-group">
				<li class="list-group-item"><a href="todas_compras">Listas de Compras</a></li>
				<li class="list-group-item"><a href="nova_compras">Nova Lista de Compras</a></li>
				<li class="list-group-item active"><a href="">Lista de Produtos</a></li>
				<li class="list-group-item"><a href="novo_produto">Novo Produto</a></li>
			</ul>
		</div>

		<div class="col-sm-9">
			<div class="container pagina">
				<div class="row">
					<div class="col">
						<h4>Listas de Produtos</h4>
						<hr />

						
						<?php foreach($produto_dados as $index => $produto) { ?>

							<div class="row mb-3 d-flex align-items-center tarefa">
								<div class="col-sm-10" id="produto_<?php echo $produto->ID_PRODUTO?>">
									<?php echo $produto->NOME ?>
								</div>
								<div class="col-sm-2 mt-2 d-flex justify-content-between">
									<i class="fas fa-edit fa-lg text-info" onclick="editar_produto(<?php echo $produto->ID_PRODUTO?>, '<?php echo $produto->NOME?>')"></i>		
									<i class="fas fa-trash-alt fa-lg text-danger"  onclick="remover_produto(<?php echo $produto->ID_PRODUTO?>)"></i>							
								</div>
							</div>

						<?php } ?>

						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>