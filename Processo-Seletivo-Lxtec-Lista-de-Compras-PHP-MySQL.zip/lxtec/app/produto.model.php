<?php

class Produto{
    private $id_produto;
    private $nome;
    
    // Getter Mágico
    public function __get($atributo){
        return $this->$atributo;
    }
    // Setter Mágico
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
}


?>